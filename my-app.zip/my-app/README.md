# MyApp — Vite + React + TypeScript + Tailwind CSS

A clean, production-ready starter template.

## 🚀 Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Open in browser
# http://localhost:5173
```

## 📦 Build for Production

```bash
npm run build
npm run preview
```

## 🗂️ Project Structure

```
my-app/
├── public/               # Static assets
│   └── favicon.svg
├── src/
│   ├── assets/           # Images, icons, fonts
│   ├── components/       # Reusable UI components
│   │   ├── Navbar.tsx
│   │   ├── Hero.tsx
│   │   ├── Features.tsx
│   │   ├── Testimonials.tsx
│   │   ├── Contact.tsx
│   │   └── Footer.tsx
│   ├── hooks/            # Custom React hooks
│   │   └── useScrollPosition.ts
│   ├── pages/            # Page-level components
│   │   └── Home.tsx
│   ├── styles/           # Global styles
│   │   └── index.css
│   ├── types/            # TypeScript type definitions
│   │   └── index.ts
│   ├── App.tsx
│   └── main.tsx
├── .vscode/
│   ├── extensions.json   # Recommended extensions
│   └── settings.json     # Editor settings
├── index.html
├── tailwind.config.js
├── postcss.config.js
├── vite.config.ts
├── tsconfig.json
└── package.json
```

## 🛠️ Tech Stack

| Tool | Version | Purpose |
|------|---------|---------|
| Vite | 5.x | Build tool & dev server |
| React | 18.x | UI framework |
| TypeScript | 5.x | Type safety |
| Tailwind CSS | 3.x | Utility-first styling |

## 📝 Recommended VSCode Extensions

Install recommended extensions when prompted, or manually:
- **Tailwind CSS IntelliSense** — autocomplete for Tailwind classes
- **ESLint** — code linting
- **Prettier** — code formatting
- **TypeScript Next** — enhanced TS support
