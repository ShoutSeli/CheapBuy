import { useState, type FormEvent } from 'react'

export default function Contact() {
  const [submitted, setSubmitted] = useState(false)
  const [email, setEmail] = useState('')

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    if (email) {
      setSubmitted(true)
      setEmail('')
    }
  }

  return (
    <section id="contact" className="py-32 px-6">
      <div className="max-w-3xl mx-auto text-center">
        <p className="font-mono text-xs text-rust tracking-[0.3em] uppercase mb-6">✦ Get Started</p>
        <h2 className="font-display text-5xl md:text-7xl font-black text-ink leading-tight mb-6">
          Ready to build?
        </h2>
        <p className="font-body text-ink/60 text-lg mb-12 leading-relaxed">
          Drop your email and we'll send you the quick-start guide to get your project running in minutes.
        </p>

        {submitted ? (
          <div className="bg-sage/10 border border-sage/30 rounded-2xl px-8 py-6 inline-block">
            <p className="font-display text-2xl text-sage font-bold mb-1">You're in! ✓</p>
            <p className="font-body text-ink/60 text-sm">Check your inbox for the quick-start guide.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="flex-1 font-body text-sm px-5 py-4 rounded-full border border-ink/20 bg-white/60 text-ink placeholder:text-ink/30 focus:outline-none focus:border-rust focus:ring-2 focus:ring-rust/20 transition"
            />
            <button
              type="submit"
              className="bg-rust text-cream font-body font-medium text-sm px-7 py-4 rounded-full hover:bg-ink transition-colors duration-300 whitespace-nowrap"
            >
              Send Guide →
            </button>
          </form>
        )}

        {/* Stack info */}
        <div className="mt-20 pt-12 border-t border-ink/10">
          <p className="font-mono text-xs text-ink/30 tracking-widest uppercase mb-6">Quick-start command</p>
          <code className="font-mono text-sm bg-ink text-gold px-6 py-3 rounded-xl inline-block">
            npm create vite@latest my-app -- --template react-ts
          </code>
        </div>
      </div>
    </section>
  )
}
