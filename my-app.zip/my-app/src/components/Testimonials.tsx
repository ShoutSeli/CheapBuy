import type { Testimonial } from '../types'

const testimonials: Testimonial[] = [
  {
    id: 1,
    quote: 'This starter saved us weeks. The folder structure is intuitive and everything just works out of the box.',
    author: 'Ama Owusu',
    role: 'Frontend Lead @ TechCo',
  },
  {
    id: 2,
    quote: "The Tailwind + TypeScript combo here is perfectly configured. I haven't touched the config once.",
    author: 'Kwame Asante',
    role: 'Indie Developer',
  },
  {
    id: 3,
    quote: 'Finally a starter that doesn\'t come with 40 dependencies I\'ll never use. Clean and focused.',
    author: 'Efua Mensah',
    role: 'Senior Engineer @ Fintech',
  },
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-32 px-6 bg-ink">
      <div className="max-w-6xl mx-auto">
        <div className="mb-20">
          <p className="font-mono text-xs text-rust tracking-[0.3em] uppercase mb-4">✦ Testimonials</p>
          <h2 className="font-display text-5xl md:text-6xl font-black text-cream leading-tight">
            Loved by developers
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="border border-cream/10 rounded-2xl p-8 hover:border-rust/40 hover:bg-white/5 transition-all duration-300"
            >
              <div className="font-display text-gold text-4xl mb-6 leading-none">"</div>
              <p className="font-body text-cream/70 text-sm leading-relaxed mb-8 italic">{t.quote}</p>
              <div>
                <div className="font-body font-medium text-cream text-sm">{t.author}</div>
                <div className="font-mono text-xs text-cream/40 tracking-wide mt-0.5">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
