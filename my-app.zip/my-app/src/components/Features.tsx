import type { Feature } from '../types'

const features: Feature[] = [
  {
    id: 1,
    icon: '⚡',
    title: 'Lightning Fast',
    description: 'Vite delivers near-instant HMR and optimized builds so you spend more time building and less time waiting.',
  },
  {
    id: 2,
    icon: '🔷',
    title: 'Type Safe',
    description: 'TypeScript gives you confidence at scale. Catch bugs before they happen with full end-to-end type safety.',
  },
  {
    id: 3,
    icon: '🎨',
    title: 'Tailwind CSS',
    description: 'A utility-first CSS framework that lets you build any design, directly in your markup without leaving HTML.',
  },
  {
    id: 4,
    icon: '🧩',
    title: 'Component Ready',
    description: 'React 18 with a scalable folder structure. Drop in your components and start building immediately.',
  },
  {
    id: 5,
    icon: '📦',
    title: 'Zero Config',
    description: 'Everything is configured and ready to run. Clone, install, and launch with a single command.',
  },
  {
    id: 6,
    icon: '🚀',
    title: 'Deploy Anywhere',
    description: 'Build for production with one command. Deploy to Vercel, Netlify, or any static host effortlessly.',
  },
]

export default function Features() {
  return (
    <section id="features" className="py-32 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-20 max-w-2xl">
          <p className="font-mono text-xs text-rust tracking-[0.3em] uppercase mb-4">✦ Features</p>
          <h2 className="font-display text-5xl md:text-6xl font-black text-ink leading-tight mb-6">
            Everything you need
            <br />
            to ship <em className="not-italic text-sage">fast.</em>
          </h2>
          <p className="font-body text-ink/60 text-lg leading-relaxed">
            This starter includes the essentials to build modern web applications with great developer experience.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={feature.id}
              className="group relative bg-white/60 border border-ink/8 rounded-2xl p-8 hover:border-rust/30 hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="text-4xl mb-5">{feature.icon}</div>
              <h3 className="font-display font-bold text-xl text-ink mb-3">{feature.title}</h3>
              <p className="font-body text-ink/55 text-sm leading-relaxed">{feature.description}</p>

              {/* Decorative corner */}
              <div className="absolute top-4 right-4 w-2 h-2 bg-rust/20 rounded-full group-hover:bg-rust/60 transition-colors duration-300" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
