export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background texture */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      {/* Decorative circle */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-rust/10 pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full border border-rust/5 pointer-events-none" />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Eyebrow */}
        <p className="animate-fade-up animation-fill-both font-mono text-xs text-rust tracking-[0.3em] uppercase mb-6">
          ✦ Welcome to the future ✦
        </p>

        {/* Headline */}
        <h1 className="animate-fade-up animation-fill-both animation-delay-100 font-display text-6xl md:text-8xl font-black text-ink leading-[0.95] mb-8">
          Build Something
          <br />
          <em className="text-rust not-italic">Remarkable.</em>
        </h1>

        {/* Subtitle */}
        <p className="animate-fade-up animation-fill-both animation-delay-200 font-body text-lg md:text-xl text-ink/60 max-w-xl mx-auto leading-relaxed mb-12">
          A modern, production-ready starter with Vite, React, TypeScript, and Tailwind CSS. 
          Everything you need — nothing you don't.
        </p>

        {/* CTAs */}
        <div className="animate-fade-up animation-fill-both animation-delay-300 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#features"
            className="bg-rust text-cream font-body font-medium px-8 py-4 rounded-full hover:bg-ink transition-colors duration-300 text-sm tracking-wide"
          >
            Explore Features
          </a>
          <a
            href="https://vitejs.dev"
            target="_blank"
            rel="noopener noreferrer"
            className="border border-ink/20 text-ink font-body font-medium px-8 py-4 rounded-full hover:border-rust hover:text-rust transition-colors duration-300 text-sm tracking-wide"
          >
            View Docs ↗
          </a>
        </div>

        {/* Tech badges */}
        <div className="animate-fade-up animation-fill-both animation-delay-400 flex flex-wrap items-center justify-center gap-3 mt-16">
          {['Vite 5', 'React 18', 'TypeScript 5', 'Tailwind CSS 3'].map((tech) => (
            <span
              key={tech}
              className="font-mono text-xs px-3 py-1.5 bg-ink/5 border border-ink/10 rounded-full text-ink/50"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span className="font-mono text-[10px] text-ink/30 tracking-widest uppercase">Scroll</span>
        <div className="w-px h-8 bg-gradient-to-b from-ink/30 to-transparent" />
      </div>
    </section>
  )
}
