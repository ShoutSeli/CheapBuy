export default function Footer() {
  return (
    <footer className="bg-ink border-t border-cream/10 py-10 px-6">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <span className="font-display text-xl font-bold text-cream">
          My<span className="text-rust">App</span>
        </span>
        <p className="font-body text-xs text-cream/30">
          Built with Vite · React · TypeScript · Tailwind CSS
        </p>
        <p className="font-body text-xs text-cream/30">
          © {new Date().getFullYear()} MyApp. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
